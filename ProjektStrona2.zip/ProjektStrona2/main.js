const btnMenu = document.querySelector("button.callMenu")
const menu = document.querySelector('nav')
const contact = document.querySelector('button.contact')
const contactBar = document.querySelector("footer.contactBar")
const gallery = document.querySelector('div.gallery')
const galleryCall = document.querySelector('button.gallery')

btnMenu.addEventListener('click', ()=>{
menu.classList.toggle('active')
btnMenu.classList.toggle ('active')
})

contact.addEventListener('click', ()=> {
    contactBar.classList.toggle('active')
})


galleryCall.addEventListener('click', ()=>{
    gallery.classList.toggle('active')
})
